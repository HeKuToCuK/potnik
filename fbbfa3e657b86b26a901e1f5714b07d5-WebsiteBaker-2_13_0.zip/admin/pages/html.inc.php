<!DOCTYPE HTML>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title></title>
  <meta name="Referrer-Policy" content="no-referrer | same-origin"/>
  <meta name="description" content="tmp" />
  <meta name="keywords" content="tmp" />
<!-- meta information for search engines -->
    <meta http-equiv="imagetoolbar" content="no" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="robots" content="index,follow" />
    <meta http-equiv="Content-Encoding" content="gzip" />
    <meta http-equiv="Accept-Encoding" content="gzip, deflate" />
<!-- site stylesheet (site colors and layout definitions) -->
    <link rel="stylesheet" type="text/css" href="" media="screen" />
    <script src="" ></script>
</head>
<body>
    <div class="content">
        <h3>Put your content here</h3>
    </div>
</body>
</html>